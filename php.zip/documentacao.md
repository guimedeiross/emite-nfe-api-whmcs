## Códigos de erros

- 1000 - Erro ao coletar dados API do IBGE - Função extract_id_city_based_on_name em utils.php
- 1001 - Cliente Id ou Email são obrigatórios - Função get_clients_details em WhmcsAPI.php
- 1002 - Erro ao atualizar notas da NF de ID $id - Função build_nfe em post.php
- 1003 - Tamanho do campo CPF/CNPJ $CPF/CNPJ do cliente $idInvoice está com problemas - Função verify_cpf_or_cnpj em utils.php
- 1004 - Erro ao enviar requisição POST - Função execute_post em post.php
- 1005 - Erro ao atualizar notas da NF de ID $id no POST - Função execute_post em post.php
- 1006 - Erro ao verificar protocolo - Função consulta_lote em consultaLote.php
- 1007 - Erro ao enviar EmailDetalhes erro: $erroMensagem - Função sendMail em sendMail.php
- 1008 - Problema ao emitir a NF de ID $id - Função execute_post em post.php
- 1009 - Erro ao atualizar notas da NF de ID $id no POST - Função add_log_error em utils.php
- 1010 - Erro ao atualizar campo notas da NF de ID $id - Função build_nfe em post.php
- 1011 - Erro ao enviar requisição POST - Função execute_post em postSemPagar.php
- 1012 - Erro ao atualizar campo notas da NF de ID $id - Função build_nfe em postSemPagar.php
- 1013 - Problema ao emitir a NF de ID $id - Função execute_post em postSemPagar.php
- 1014 - Erro ao atualizar notas da NF de ID $id - Função build_nfe em postSemPagar.php
- 1015 - Erro ao atualizar notas da NF de ID $id no POST - Função execute_post em postSemPagar.php