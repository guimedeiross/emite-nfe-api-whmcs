<?php

declare(strict_types=1);

use \Throwable as Throwable;

require_once 'utils.php';

require_once './WHMCS/WhmcsApi.php';
require_once './consultaLote.php';

$GLOBALS['utils'] = new Utils;
$GLOBALS['qtdeNFFiltrada'] = 0;

$WhmcsApi = new WhmcsApi;

function build_nfe(WhmcsApi $WhmcsApi)//: array
{
    $Nfs = [];
    $nf1 = array(
        'numeroRps' => '200250',
        'serieRps' => "302",
        'dataEmissao' => "2022-10-31",
        'dataCompetencia' => "2022-11-07",
        'valorServico' => "124.00",
        'cpf' => $GLOBALS['utils']->format_cpf_and_cnpj_and_cep("686.271.069-91"),
        'razaoSocial' => "Alexandre Alberto da Cunha",
        'endereco' => "Rua Das Papoulas 256",
        'numero' => "",
        'bairro' => "Iririu",
        'codigoMunicipio' => '4209102',
        'uf' => "SC",
        'cep' => $GLOBALS['utils']->format_cpf_and_cnpj_and_cep("89227-555"),
        'email' => "guilherme.medeiros@joinvix.com.br",
        'discriminacao' => "Site Gerenciável - 8df944ae7b (07/11/2022 - 06/12/2022)" . PHP_EOL . "Hospedagem Cloud 10GB - boaformabrasil.com.br (07/11/2022 - 06/12/2022)"
    );
    array_push($Nfs, $nf1);
    return $Nfs;
}

build_nfe($WhmcsApi);

/* 
try {
    $Nfs = build_nfe($WhmcsApi);
    if (count($Nfs) > 0) execute_post($Nfs[0]);
} catch (\Throwable $th2) {
    $GLOBALS['utils']->add_log_error($th2);
}

function verifica_emitiu_nf(string $result): int
{
    $consultaLote = new ConsultaLote;
    $protocol = $consultaLote->parse_XML($result, 'Protocolo');
    $situacao = $consultaLote->consulta_lote($protocol);
    return intval($situacao);
}

function execute_post(array $NfsToPost): void
{
    
    $WhmcsApi = new WhmcsApi;
    try {
        $URL_SEND_POST = $_ENV['URL_SEND_POST'];
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $URL_SEND_POST);
        curl_setopt($ch, CURLOPT_POST, true);
        curl_setopt($ch, CURLOPT_FAILONERROR, true);
        curl_setopt($ch, CURLOPT_HTTPHEADER, array('Content-Type: application/json'));
        curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode(array($NfsToPost)));
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        $result = curl_exec($ch);
        $http_status = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        if ($http_status !== 200) throw new Exception("Erro ao enviar requisição POST", 1004);
        curl_close($ch);
        var_dump($result);
        $resultDecode = json_decode($result);
        if ($resultDecode == NULL) {
            //quando emite NF entra aqui
            do {
                $situacao = verifica_emitiu_nf($result);
            } while ($situacao === 2);
            $pattern = "/__e__NFEEMITIDA|__e__PROBLEMA$/";
            if ($situacao !== 4) {
                throw new Exception('Problema ao emitir a NF de ID ' . $NfsToPost['numeroRps'], 1008);
            } else {
                //emite NF
                $generator = $WhmcsApi->update_invoice_notes_default(intval($NfsToPost['numeroRps']));
                var_dump($result);
                foreach ($generator as $updateNote) {
                    if ($updateNote['result'] !== 'success') throw new Exception('Erro ao atualizar notas da NF de ID ' . strval($NfsToPost['numeroRps']), 1002);
                }
                file_put_contents('ProtocolosEmitidos.txt', $result . PHP_EOL, FILE_APPEND);
            }
        } else {
            var_dump($resultDecode);
        }
    } catch (\Throwable $th) {
        $generator = $WhmcsApi->update_invoice_notes_default(intval($NfsToPost['numeroRps']), true);
        foreach ($generator as $updateNote) {
            if ($updateNote['result'] !== 'success') throw new Exception('Erro ao atualizar notas da NF de ID ' . $NfsToPost['numeroRps'] . ' no POST', 1005);
        }
        $GLOBALS['utils']->add_log_error($th);
    }
} */
